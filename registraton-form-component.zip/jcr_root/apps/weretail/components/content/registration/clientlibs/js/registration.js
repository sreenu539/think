const FormModule = (function() {


	function submitForm(url, form) {
		const formData = new FormData(form);

		fetch(url, {
				method: "POST",
				body: formData,
			})
			.then(response => response.json())
			.then(data => {
				console.log("success");
			})
			.catch(error => {
				console.error("Fetch Error:", error);
			});
	}


	function validateFormElements() {
		const errors = [];

		const firstNameField = document.getElementById("aria_first_name");
		const lastNameField = document.getElementById("aria_last_name");
		const emailField = document.getElementById("aria_email");
		const passwordField = document.getElementById("aria_password");
		const confirmPasswordField = document.getElementById("aria_confirm_password");

		if (!firstNameField || !lastNameField || !emailField || !passwordField || !confirmPasswordField) {
			errors.push("Something wrong with the form. Please contact customer support.");
			return errors;
		}

		if (firstNameField.value.trim() === "") {
			errors.push("First name is required.");
		}

		if (lastNameField.value.trim() === "") {
			errors.push("Last name is required.");
		}

		if (emailField.value.trim() === "") {
			errors.push("Email is required.");
		}

		if (passwordField.value.trim() === "") {
			errors.push("Password is required.");
		}

		if (confirmPasswordField.value.trim() === "") {
			errors.push("Confirm Password is required.");
		}

		const value = passwordField.value;
		const confirmPasswordValue = confirmPasswordField.value;

		const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

		if (!passwordRegex.test(value)) {
			errors.push("Password does not meet criteria. Please choose a strong password.");
		}

		if (value !== confirmPasswordValue) {
			errors.push("Please check password and confirm password values.");
		}

        const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;

        if(!emailRegex.test(emailField.value)) {
			errors.push("Please provide a valid email");
        }    


		return errors;
	}


	function submitButtonFunction() {

		const form = document.getElementById("registration-form");
		const url = form.getAttribute("action");

		let errors = validateFormElements();

		if (errors.length === 0) {

            document.getElementById("error-container").innerHTML = "";
            document.getElementById("error-label").classList.add("hidden");

			submitForm(url, form);
		} else {
			UIModule.showStatusOnSubmit(errors);
		}
	}

	// Public methods
	return {
		submitButtonFunction: submitButtonFunction,
	};
})();

// Module for UI-related functions
const UIModule = (function() {
	function showStatusOnSubmit(messages) {

		const showStatusOnSubmit = document.getElementById("error-container");
        showStatusOnSubmit.setAttribute("tabindex", "-1");
        showStatusOnSubmit.focus();
        document.getElementById("error-label").classList.remove("hidden");
		showStatusOnSubmit.innerHTML = "<ul>" + messages.map(error => `<li>${error}</li>`).join("") + "</ul>";
		showStatusOnSubmit.style.color = "red";


	}

	// Public methods
	return {
		showStatusOnSubmit: showStatusOnSubmit,
	};
})();

// Event listener
document.addEventListener("DOMContentLoaded", function() {
	const submitButton = document.getElementById("form-submit-btn");

	submitButton.addEventListener("click", function(e) {
		e.preventDefault();
		FormModule.submitButtonFunction();
	});
});